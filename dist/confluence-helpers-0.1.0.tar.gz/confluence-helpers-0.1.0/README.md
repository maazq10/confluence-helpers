# confluence-helpers
Some helper functions to easily programmatically interface with Atlassian Confluence 


HOW TO:
Retrieve an API key from Atlassian Confluence website.
Recommended to save this key in a key vault or secret manager.
When using the Confluence API, store username/email and password/API key in a tuple, and pass that to the functions.
EX: (Username, API_token)
